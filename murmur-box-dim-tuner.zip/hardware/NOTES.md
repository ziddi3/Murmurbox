# Hardware Notes
- Prefer I²C breakout boards for fast wiring.
- Keep sensor cables short to reduce noise.
- Shield your DIY EMF coil if possible; route its analog output through an LM358 to an ADS1115.
- Thermal printer draws real current: use a dedicated 5V rail or a beefy power bank.
- The Camera Module v3 NoIR sees in IR; add an IR illuminator if working in the dark.
